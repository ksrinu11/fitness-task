
"""Fitness Studio Booking API (modular version)."""
